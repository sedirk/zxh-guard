//go:build !tun

package main

import (
	"context"
	"crypto"
	"crypto/tls"
	"net"
	"os"
	"os/signal"
	"runtime"
	"strconv"
	"syscall"
	"time"

	"github.com/containers/winquit/pkg/winquit"
	"github.com/mythologyli/zju-connect/client"
	atrustclient "github.com/mythologyli/zju-connect/client/atrust"
	"github.com/mythologyli/zju-connect/client/atrust/auth"
	easyconnectclient "github.com/mythologyli/zju-connect/client/easyconnect"
	"github.com/mythologyli/zju-connect/configs"
	"github.com/mythologyli/zju-connect/dial"
	"github.com/mythologyli/zju-connect/internal/hook_func"
	"github.com/mythologyli/zju-connect/internal/keylog"
	"github.com/mythologyli/zju-connect/log"
	"github.com/mythologyli/zju-connect/resolve"
	"github.com/mythologyli/zju-connect/service"
	"github.com/mythologyli/zju-connect/stack"
	"github.com/mythologyli/zju-connect/stack/gvisor"
	"github.com/mythologyli/zju-connect/stack/tcptunnel"
	"github.com/mythologyli/zju-connect/stack/tun"
	"github.com/mythologyli/zju-connect/underlay"
	"golang.org/x/crypto/pkcs12"
	"inet.af/netaddr"
)

var conf configs.Config

func main() {
	if exitCode := initialize(os.Args[1:]); exitCode >= 0 {
		os.Exit(exitCode)
	}

	log.Init()

	log.Println("Start ZJU Connect " + zjuConnectVersionString())
	if conf.DebugDump {
		log.EnableDebug()
	}
	if errs := hook_func.ExecInitialFunc(context.Background(), conf); errs != nil {
		for _, err := range errs {
			log.Printf("Initial ZJU-Connect failed: %s", err)
		}
		os.Exit(1)
	}
	underlayDialer, underlayErr := underlay.New(underlay.Options{
		InterfaceName:  conf.BindInterface,
		AutoDetect:     conf.AutoDetectInterface,
		DebugPCAPFile:  conf.DebugPCAPFile,
		LocalDNSServer: conf.LocalDNSServer,
	})
	if underlayErr != nil {
		log.Fatalf("Create underlay dialer: %v", underlayErr)
	}
	tlsKeyLogWriter, tlsKeyLogErr := keylog.Open(conf.DebugTLSLogFile)
	if tlsKeyLogErr != nil {
		_ = underlayDialer.Close()
		log.Fatalf("Create TLS key log: %v", tlsKeyLogErr)
	}
	if conf.DebugPCAPFile != "" {
		log.Printf("VPN underlay PCAP capture enabled: %s", conf.DebugPCAPFile)
	}
	if conf.DebugTLSLogFile != "" {
		log.Printf("TLS key logging enabled: %s", conf.DebugTLSLogFile)
	}
	var vpnClient client.Client
	switch conf.Protocol {
	case "easyconnect":
		tlsCert := tls.Certificate{}
		if conf.CertFile != "" {
			p12Data, err := os.ReadFile(conf.CertFile)
			if err != nil {
				log.Fatalf("Read certificate file error: %s", err)
			}

			key, cert, err := pkcs12.Decode(p12Data, conf.CertPassword)
			if err != nil {
				log.Fatalf("Decode certificate file error: %s", err)
			}

			tlsCert = tls.Certificate{
				Certificate: [][]byte{cert.Raw},
				PrivateKey:  key.(crypto.PrivateKey),
				Leaf:        cert,
			}
		}

		vpnClient = easyconnectclient.NewClient(easyconnectclient.Options{
			Server: net.JoinHostPort(conf.ServerAddress, strconv.Itoa(conf.ServerPort)),
			Auth: easyconnectclient.AuthOptions{
				Username:      conf.Username,
				Password:      conf.Password,
				TOTPSecret:    conf.TOTPSecret,
				Certificate:   tlsCert,
				GraphCodeFile: conf.GraphCodeFile,
			},
			SessionID:     conf.TwfID,
			TestMultiLine: !conf.DisableMultiLine,
			Resources: easyconnectclient.ResourceOptions{
				Fetch:          !conf.DisableServerConfig,
				IncludeDomains: !conf.SkipDomainResource,
			},
			UnderlayDialer:  underlayDialer,
			TLSKeyLogWriter: tlsKeyLogWriter,
		})

		log.Printf("VPN protocol: %s", conf.Protocol)
		err := vpnClient.(*easyconnectclient.Client).Setup()
		if err != nil {
			vpnClient.(*easyconnectclient.Client).Close()
			_ = underlayDialer.Close()
			if tlsKeyLogWriter != nil {
				_ = tlsKeyLogWriter.Close()
			}
			log.Fatalf("VPN client setup error: %s", err)
		}
	case "atrust":
		var err error
		var resourceData []byte

		if conf.ResourceFile != "" {
			resourceData, err = os.ReadFile(conf.ResourceFile)
			if err != nil {
				log.Fatalf("Read resource file error: %s", err)
			}
		}

		var clientData []byte
		if conf.ClientDataFile != "" {
			clientData, err = os.ReadFile(conf.ClientDataFile)
			if err != nil {
				log.Printf("Read client data file error: %s", err)
				log.Println("Will create a new client data file if log in successfully")
			}
		}

		var loginMethod auth.LoginMethod
		if conf.SID == "" || conf.DeviceID == "" || resourceData == nil {
			loginMethod, err = auth.NewLoginMethod(auth.LoginMethodOptions{
				AuthType:      conf.AuthType,
				Username:      conf.Username,
				Password:      conf.Password,
				Phone:         conf.Phone,
				Domain:        conf.LoginDomain,
				GraphCodeFile: conf.GraphCodeFile,
				CASTicket:     conf.CasTicket,
				OAuth2Code:    conf.OAuth2Code,
			})
			if err != nil {
				log.Fatalf("Configure aTrust login: %v", err)
			}
		}

		vpnClient = atrustclient.NewClient(atrustclient.ClientOptions{
			Session: atrustclient.SessionOptions{
				Username: conf.Username,
				SID:      conf.SID,
				DeviceID: conf.DeviceID,
				SignKey:  conf.SignKey,
			},
			UnderlayDialer:  underlayDialer,
			TLSKeyLogWriter: tlsKeyLogWriter,
		})

		log.Printf("VPN protocol: %s", conf.Protocol)
		clientData, err = vpnClient.(*atrustclient.Client).Setup(atrustclient.SetupOptions{
			ServerAddress:            conf.ServerAddress,
			ServerPort:               conf.ServerPort,
			LoginMethod:              loginMethod,
			TOTPSecret:               conf.TOTPSecret,
			ClientData:               clientData,
			ResourceData:             resourceData,
			BestNodesRefreshInterval: time.Duration(conf.UpdateBestNodesInterval) * time.Second,
		})
		if err != nil {
			vpnClient.(*atrustclient.Client).Close()
			_ = underlayDialer.Close()
			if tlsKeyLogWriter != nil {
				_ = tlsKeyLogWriter.Close()
			}
			log.Fatalf("VPN client setup error: %s", err)
		}

		if conf.ClientDataFile != "" {
			err = os.WriteFile(conf.ClientDataFile, clientData, 0644)
			if err != nil {
				log.Fatalf("Write client data file error: %s", err)
			}
			log.Printf("Client data saved to %s", conf.ClientDataFile)
		}
	}

	log.Printf("VPN client started")
	if closer, ok := vpnClient.(interface{ Close() }); ok {
		hook_func.RegisterTerminalFunc("CloseVPNClient", func(ctx context.Context) error {
			closer.Close()
			return nil
		})
	}
	hook_func.RegisterTerminalFunc("CloseUnderlayDialer", func(ctx context.Context) error {
		return underlayDialer.Close()
	})
	if tlsKeyLogWriter != nil {
		hook_func.RegisterTerminalFunc("CloseTLSKeyLog", func(ctx context.Context) error {
			return tlsKeyLogWriter.Close()
		})
	}

	ipResources, err := vpnClient.IPResources()
	if err != nil && !conf.DisableServerConfig {
		log.Println("No IP resources")
	}

	ipSet, err := vpnClient.IPSet()
	if err != nil && !conf.DisableServerConfig {
		log.Println("No IP set")
	}

	domainResources, err := vpnClient.DomainResources()
	if err != nil && !conf.DisableServerConfig {
		log.Println("No domain resources")
	}

	dnsResource, err := vpnClient.DNSResource()
	if err != nil && !conf.DisableServerConfig {
		log.Println("No DNS resource")
	}

	if conf.Protocol == "easyconnect" {
		if !conf.DisableZJUConfig {
			if domainResources == nil {
				domainResources = make(client.DomainResources)
			}

			domainResources["zju.edu.cn"] = []client.DomainResource{{
				PortMin:  1,
				PortMax:  65535,
				Protocol: "all",
			}}

			if ipResources == nil {
				ipResources = []client.IPResource{}
			}

			ipResources = append([]client.IPResource{{
				IPMin:    net.ParseIP("10.0.0.0"),
				IPMax:    net.ParseIP("10.255.255.255"),
				PortMin:  1,
				PortMax:  65535,
				Protocol: "all",
			}}, ipResources...)

			ipSetBuilder := netaddr.IPSetBuilder{}
			if ipSet != nil {
				ipSetBuilder.AddSet(ipSet)
			}
			ipSetBuilder.AddPrefix(netaddr.MustParseIPPrefix("10.0.0.0/8"))
			ipSet, _ = ipSetBuilder.IPSet()
		}

		for _, customProxyDomain := range conf.CustomProxyDomain {
			if domainResources != nil {
				domainResources[customProxyDomain] = append(domainResources[customProxyDomain], client.DomainResource{
					PortMin:  1,
					PortMax:  65535,
					Protocol: "all",
				})
			} else {
				domainResources = client.DomainResources{
					customProxyDomain: {{
						PortMin:  1,
						PortMax:  65535,
						Protocol: "all",
					}},
				}
			}
		}
	}

	var vpnStack stack.Stack
	if conf.TCPTunnelMode {
		vpnStack, err = tcptunnel.NewStack(vpnClient)
		if err != nil {
			log.Fatalf("TCP Tunnel stack setup error: %s", err)
		}
	} else if conf.TUNMode {
		vpnTUNStack, err := tun.NewStack(vpnClient, conf.DNSHijack, conf.FakeIP, ipResources)
		if err != nil {
			log.Fatalf("Tun stack setup error, make sure you are root user : %s", err)
		}

		if conf.AddRoute && ipSet != nil {
			for _, prefix := range ipSet.Prefixes() {
				log.Printf("Add route to %s", prefix.String())
				_ = vpnTUNStack.AddRoute(prefix.String())
			}
		} else if !conf.AddRoute && !conf.DisableZJUConfig && conf.Protocol == "easyconnect" {
			log.Println("Add route to 10.0.0.0/8")
			_ = vpnTUNStack.AddRoute("10.0.0.0/8")
		}

		if conf.FakeIP {
			_ = vpnTUNStack.AddRoute("198.18.0.0/16")
		}

		vpnStack = vpnTUNStack
	} else {
		vpnStack, err = gvisor.NewStack(vpnClient)
		if err != nil {
			log.Fatalf("gVisor stack setup error: %s", err)
		}
	}

	useRemoteDNS := !conf.DisableRemoteDNS
	remoteDNSServer := conf.RemoteDNSServer
	policyDNSServers, _ := vpnClient.DNSServers()
	if useRemoteDNS && remoteDNSServer == "auto" {
		remoteDNSServer, err = vpnClient.DNSServer()
		if err != nil {
			useRemoteDNS = false
			remoteDNSServer = "10.10.0.21"
			log.Println("No DNS server provided by server. Disable remote DNS")
		} else {
			log.Printf("Use DNS server %s provided by server", remoteDNSServer)
		}
	}
	secondaryDNSServer := conf.SecondaryDNSServer
	if secondaryDNSServer == "auto" {
		secondaryDNSServer = "114.114.114.114"
		if len(policyDNSServers) > 1 {
			secondaryDNSServer = policyDNSServers[1]
			log.Printf("Use secondary DNS server %s provided by server", secondaryDNSServer)
		}
	}

	vpnResolver := resolve.NewResolver(
		vpnStack,
		remoteDNSServer,
		secondaryDNSServer,
		conf.DNSTTL,
		domainResources,
		dnsResource,
		useRemoteDNS,
	)
	hook_func.RegisterTerminalFunc("CloseResolver", func(ctx context.Context) error {
		vpnResolver.Close()
		return nil
	})

	for _, customDns := range conf.CustomDNSList {
		ipAddr := net.ParseIP(customDns.IP)
		if ipAddr == nil {
			log.Printf("Custom DNS for host name %s is invalid, SKIP", customDns.HostName)
		}
		vpnResolver.SetPermanentDNS(customDns.HostName, ipAddr)
		log.Printf("Add custom DNS: %s -> %s\n", customDns.HostName, customDns.IP)
	}
	localResolver := service.NewDnsServer(vpnResolver, []string{remoteDNSServer, conf.SecondaryDNSServer})
	vpnStack.SetupResolve(localResolver)
	vpnStack.SetupIPPool(vpnResolver.IPPool)

	go vpnStack.Run()

	vpnDialer := dial.NewDialer(vpnStack, vpnResolver, ipResources, conf.ProxyAll, conf.DialDirectProxy)

	if conf.DNSServerBind != "" {
		go service.ServeDNS(conf.DNSServerBind, localResolver)
	}
	if conf.TUNMode {
		clientIP, _ := vpnClient.IP()
		go service.ServeDNS(clientIP.String()+":53", localResolver)
	}

	if conf.SocksBind != "" {
		go service.ServeSocks5(conf.SocksBind, vpnDialer, vpnResolver, conf.SocksUser, conf.SocksPasswd)
	}

	if conf.HTTPBind != "" {
		go service.ServeHTTP(conf.HTTPBind, vpnDialer)
	}

	if conf.ShadowsocksURL != "" {
		go service.ServeShadowsocks(vpnDialer, conf.ShadowsocksURL)
	}

	for _, portForwarding := range conf.PortForwardingList {
		switch portForwarding.NetworkType {
		case "tcp":
			go service.ServeTCPForwarding(vpnStack, portForwarding.BindAddress, portForwarding.RemoteAddress)
		case "udp":
			go service.ServeUDPForwarding(vpnStack, portForwarding.BindAddress, portForwarding.RemoteAddress)
		default:
			log.Printf("Port forwarding: unknown network type %s. Aborting", portForwarding.NetworkType)
		}
	}

	if !conf.DisableKeepAlive {
		if conf.KeepAliveURL == "" && !useRemoteDNS {
			log.Println("Keep alive is disabled because remote DNS is disabled, and no KeepAliveURL is provided")
		} else {
			keepAliveCtx, keepAliveCancel := context.WithCancel(context.Background())
			hook_func.RegisterTerminalFunc("CloseKeepAlive", func(ctx context.Context) error {
				keepAliveCancel()
				return nil
			})
			go service.KeepAlive(keepAliveCtx, vpnResolver, vpnDialer, conf.KeepAliveURL)
		}
	}

	if runtime.GOOS == "windows" {
		done := make(chan os.Signal, 1)
		signal.Notify(done, syscall.SIGINT)
		winquit.SimulateSigTermOnQuit(done)
		<-done
	} else {
		quit := make(chan os.Signal, 1)
		signal.Notify(quit, os.Interrupt, syscall.SIGTERM, syscall.SIGHUP)
		<-quit
	}
	log.Println("Shutdown ZJU-Connect ......")
	if errs := hook_func.ExecTerminalFunc(context.Background()); errs != nil {
		for _, err := range errs {
			log.Printf("Shutdown ZJU-Connect failed: %s", err)
		}
	} else {
		log.Println("Shutdown ZJU-Connect success, Bye~")
	}
}
